import React from 'react';

type IconProps = {
  className?: string;
};

export const UploadCloudIcon: React.FC<IconProps> = ({ className }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    <path d="M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242" />
    <path d="M12 12v9" />
    <path d="m16 16-4-4-4 4" />
  </svg>
);

export const BrainCircuitIcon: React.FC<IconProps> = ({ className }) => (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M12 5a3 3 0 1 0-5.993.142" />
      <path d="M18 5a3 3 0 1 0-5.993.142" />
      <path d="M18 11a3 3 0 1 0-5.993.142" />
      <path d="M12 11a3 3 0 1 0-5.993.142" />
      <path d="M12 17a3 3 0 1 0-5.993.142" />
      <path d="M18 17a3 3 0 1 0-5.993.142" />
      <path d="M9 8.556A3 3 0 0 0 9 11m0 3.111A3 3 0 0 0 9 17m6-8.444A3 3 0 0 0 15 11m0 3.111A3 3 0 0 0 15 17" />
      <path d="M12 8.556A3 3 0 0 0 12 11m0 3.111A3 3 0 0 0 12 17m-3-11.444A3 3 0 0 0 9 8" />
      <path d="M15 5.556A3 3 0 0 0 15 8" />
      <path d="M9 14.556A3 3 0 0 0 9 17m6-2.444A3 3 0 0 0 15 17m-6-11.444A3 3 0 0 1 9 5m6 .556A3 3 0 0 1 15 5" />
      <path d="M12 5.556A3 3 0 0 0 12 8m0 3.111A3 3 0 0 0 12 14" />
      <path d="M14.241 5.126a3 3 0 0 1-1.056 1.056" />
      <path d="M14.241 17.126a3 3 0 0 1-1.056 1.056" />
      <path d="M19.759 11.126a3 3 0 0 1-1.056 1.056" />
      <path d="M9.759 5.126a3 3 0 0 1-1.056 1.056" />
      <path d="M9.759 17.126a3 3 0 0 1-1.056 1.056" />
      <path d="M4.241 11.126a3 3 0 0 1-1.056 1.056" />
      <path d="M14.241 5.126a3 3 0 0 0 1.056-1.056" />
      <path d="M14.241 17.126a3 3 0 0 0 1.056-1.056" />
      <path d="M19.759 11.126a3 3 0 0 0 1.056-1.056" />
      <path d="M9.759 5.126a3 3 0 0 0 1.056-1.056" />
      <path d="M9.759 17.126a3 3 0 0 0 1.056-1.056" />
      <path d="M4.241 11.126a3 3 0 0 0 1.056-1.056" />
    </svg>
);

export const DownloadIcon: React.FC<IconProps> = ({ className }) => (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
      <polyline points="7 10 12 15 17 10" />
      <line x1="12" y1="15" x2="12" y2="3" />
    </svg>
  );
  
export const PdfIcon: React.FC<IconProps> = ({ className }) => (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
      <polyline points="14 2 14 8 20 8" />
      <line x1="16" y1="13" x2="8" y2="13" />
      <line x1="16" y1="17" x2="8" y2="17" />
      <polyline points="10 9 9 9 8 9" />
    </svg>
);