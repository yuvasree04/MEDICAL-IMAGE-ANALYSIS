import { GoogleGenAI, Type } from "@google/genai";
import type { AnalysisResult } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const analysisSchema = {
  type: Type.OBJECT,
  properties: {
    status: {
      type: Type.STRING,
      description: "Set to 'healthy' if no anomalies are found, or 'anomaly_detected' if one or more anomalies are found. This field is mandatory."
    },
    summary: {
        type: Type.STRING,
        description: "A concise, professional summary or impression of the overall findings, similar to a radiologist's impression. This should be a single paragraph that synthesizes the key findings. If healthy, state that clearly. This field is mandatory."
    },
    findings: {
      type: Type.ARRAY,
      description: "An array of all significant anomalies found in the scan. The array will be empty if the status is 'healthy'.",
      items: {
        type: Type.OBJECT,
        properties: {
          finding: {
            type: Type.STRING,
            description: "A short, specific name for the potential medical finding or anomaly (e.g., 'Nodule', 'Fracture')."
          },
          description: {
            type: Type.STRING,
            description: "A concise, professional medical description of the potential anomaly. This description MUST include the formal and exact medical name for the suspected condition (e.g., 'Pulmonary Nodule', 'Metacarpal Fracture')."
          },
          boundingBox: {
            type: Type.OBJECT,
            description: "A bounding box enclosing the anomaly.",
            properties: {
              x: { type: Type.NUMBER, description: "The integer x-coordinate of the top-left corner of the bounding box, in pixels." },
              y: { type: Type.NUMBER, description: "The integer y-coordinate of the top-left corner of the bounding box, in pixels." },
              width: { type: Type.NUMBER, description: "The width of the bounding box, in pixels." },
              height: { type: Type.NUMBER, description: "The height of the bounding box, in pixels." }
            },
            required: ['x', 'y', 'width', 'height']
          }
        },
        required: ['finding', 'description', 'boundingBox']
      }
    }
  },
  required: ['status', 'summary', 'findings']
};


export const analyzeMedicalScan = async (base64Image: string, mimeType: string, enhance: boolean, dimensions: { width: number, height: number }): Promise<AnalysisResult> => {
  const model = "gemini-2.5-flash";

  const enhancementInstruction = enhance 
    ? `**Pre-Analysis Step:** First, apply simulated image enhancement techniques (such as adjusting contrast and brightness or applying a sharpening filter) to improve the visibility of subtle details before proceeding with the analysis.`
    : '';

  const prompt = `
    You are a specialized AI model functioning as a high-precision object detection tool for medical imaging. Your primary and most critical task is to identify and provide exact, consolidated bounding box coordinates for all potential anomalies. Your success is measured by the geometric accuracy and non-redundancy of these coordinates.

    **Image Context & Rules:**
    *   Image Width: ${dimensions.width} pixels
    *   Image Height: ${dimensions.height} pixels
    *   Coordinate System Origin (0,0) is the Top-Left Corner.
    *   All coordinates MUST be relative to this grid and fall within these boundaries.

    **Sensitivity Calibration:**
    *   **High Sensitivity Protocol:** You are to operate with heightened sensitivity. Do not only focus on obvious, high-contrast anomalies. Your task is to detect subtle and rare conditions as well.
    *   **Look for Faint Patterns:** Pay extremely close attention to faint patterns, subtle asymmetries, minor textural irregularities, and inconsistencies in density that might be indicative of nascent or uncommon pathologies.
    *   **Lower Confidence Threshold:** If you detect a potential anomaly, even with lower confidence, you should still flag it and provide a bounding box. It is better to have a potential false positive that a human can review than to miss a subtle finding. Your goal is exhaustive detection.

    **Analysis Protocol:**

    1.  **Comprehensive Anomaly Scan:** Guided by the High Sensitivity Protocol, scrutinize the entire image pixel by pixel to identify ALL potential anomalies, including the most subtle ones. For each potential finding, create an initial, tight-fitting bounding box.

    2.  **CRITICAL - Consolidation & Merging:** This is the most important step. Review all the initial bounding boxes you have identified.
        *   **Identify Overlaps:** Check for boxes that have significant overlap.
        *   **Merge Redundant Boxes:** If multiple boxes refer to the same, single underlying anomaly, you MUST merge them into ONE, all-encompassing bounding box. This new box should be a "shrink-to-fit" container around the complete anomaly.
        *   **Goal:** The final list of findings must not contain multiple, overlapping boxes for the same feature. Each distinct anomaly should be represented by exactly one box.

    3.  **Final Validation:** For EACH final, consolidated bounding box, perform these checks:
        *   **Internal Verification:** Ask yourself: "Does this box include excessive empty space?" or "Does this box cut off any part of the anomaly?". If yes, you MUST adjust the coordinates until the fit is perfect.
        *   **Boundary Check:** You MUST ensure the box is valid within the image dimensions: (x + width) must be less than or equal to ${dimensions.width}, and (y + height) must be less than or equal to ${dimensions.height}. Coordinates must be integers.

    4.  **Description Generation:** After finalizing the coordinates, provide a concise, clinical description for each finding. This description MUST start with or prominently feature the exact medical name for the suspected problem to ensure clarity and precision.

    5.  **Generate Summary Impression:** After analyzing all findings, you MUST provide a single, overarching 'summary' or 'impression'. This should be a concise paragraph that synthesizes the key findings into a clinical summary, as a radiologist would. If the scan is healthy, state that clearly.

    6.  **JSON Formatting:** Your entire output must be a single, valid JSON object matching the provided schema. If no anomalies are found, you MUST return an object with \`status\` set to 'healthy', an appropriate summary, and an empty 'findings' array. If you find any anomalies, \`status\` MUST be 'anomaly_detected' and the 'findings' array must be populated.

    ${enhancementInstruction}
    `;
  
  const imagePart = {
    inlineData: {
      data: base64Image,
      mimeType: mimeType,
    },
  };
  
  const textPart = {
      text: prompt
  };

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: { parts: [imagePart, textPart] },
      config: {
        responseMimeType: "application/json",
        responseSchema: analysisSchema,
        temperature: 0, // Set to 0 for maximum determinism and accuracy.
      },
    });

    const jsonText = response.text.trim();
    const result = JSON.parse(jsonText);
    
    // Validation
    if (result && (result.status === 'healthy' || result.status === 'anomaly_detected') && typeof result.summary === 'string' && Array.isArray(result.findings)) {
        if (result.status === 'healthy' && result.findings.length > 0) {
            throw new Error("Invalid data: 'healthy' status with non-empty findings array received from model.");
        }
        if (result.status === 'anomaly_detected' && result.findings.length === 0) {
            throw new Error("Invalid data: 'anomaly_detected' status with empty findings array received from model.");
        }
        return result as AnalysisResult;
    } else {
        throw new Error("Invalid JSON structure received from API. Expected 'status', 'summary', and 'findings' fields.");
    }
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to get a valid analysis from the AI model.");
  }
};