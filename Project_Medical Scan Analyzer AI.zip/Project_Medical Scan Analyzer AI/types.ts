export interface BoundingBox {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface Finding {
  finding: string;
  description: string;
  boundingBox: BoundingBox;
}

export interface AnalysisResult {
  status: 'healthy' | 'anomaly_detected';
  summary: string;
  findings: Finding[];
}
